package com.example.smartspendv6.data

data class LoginUsers(
    val username: String,
    val password: String
)
