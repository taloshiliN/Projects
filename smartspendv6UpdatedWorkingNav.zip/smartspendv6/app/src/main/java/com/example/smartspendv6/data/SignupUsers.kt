package com.example.smartspendv6.data

data class SignupUsers(
    val username: String,
    val email: String,
    val password: String
)
