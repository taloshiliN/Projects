package com.example.smartspendv6.data

data class Goals(
    val name: String,
    val description: String
)
