package com.example.smartspendv6.data

data class Transfer(
    val id: Int,
    val category: String,
    val description: String,
    val amount: Double
)
