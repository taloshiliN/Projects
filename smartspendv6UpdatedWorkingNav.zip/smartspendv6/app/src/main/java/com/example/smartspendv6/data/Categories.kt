package com.example.smartspendv6.data

data class Categories(
    val name: String,
    val monthly_budget: Double,
)
